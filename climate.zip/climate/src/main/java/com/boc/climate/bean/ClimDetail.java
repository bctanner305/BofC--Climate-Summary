package com.boc.climate.bean;

public class ClimDetail extends ClimSum {

	/**
	 * 
	 */ 
	private static final long serialVersionUID = 1L;

	//Constructor
	public ClimDetail( String Station_Name,
			String Date,
			String Mean_Temp,
			String province, 
			String highest_Monthly_Maxi_Temp, 
			String lowest_Monthly_Min_Temp) {
		
		super.Station_Name = Station_Name;
		super.Date = Date;
		super.Mean_Temp = Mean_Temp;
		Province = province;
		Highest_Monthly_Maxi_Temp = highest_Monthly_Maxi_Temp;
		Lowest_Monthly_Min_Temp = lowest_Monthly_Min_Temp;
	}

	//Constructo with no input fields
	public ClimDetail() {
	}
	
	private String Province;
	
	private String Highest_Monthly_Maxi_Temp;
	
	private String Lowest_Monthly_Min_Temp;

	public String getProvince() {
		return Province;
	}

	public void setProvince(String province) {
		Province = province;
	}

	public String getHighest_Monthly_Maxi_Temp() {
		return Highest_Monthly_Maxi_Temp;
	}

	public void setHighest_Monthly_Maxi_Temp(String highest_Monthly_Maxi_Temp) {
		Highest_Monthly_Maxi_Temp = highest_Monthly_Maxi_Temp;
	}

	public String getLowest_Monthly_Min_Temp() {
		return Lowest_Monthly_Min_Temp;
	}

	public void setLowest_Monthly_Min_Temp(String lowest_Monthly_Min_Temp) {
		Lowest_Monthly_Min_Temp = lowest_Monthly_Min_Temp;
	}

		
}

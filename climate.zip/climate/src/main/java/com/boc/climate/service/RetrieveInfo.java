package com.boc.climate.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boc.climate.bean.ClimDetail;
import com.boc.climate.bean.ClimSum;
import com.boc.climate.util.CSVReader;


@Service
public class RetrieveInfo {

	List<ClimSum> climSumList;

	@Autowired
	private CSVReader cvsReader;

	private static final Logger logger = Logger.getLogger(RetrieveInfo.class);

	public List<ClimSum> getSummaryList(String climatestartdate, String climateenddate, String climatePeriodlist) {

		logger.info("Method: getSummaryList, startdate: " + climatestartdate + ", enddate:" + climateenddate+ ", climatePeriodlist:" + climatePeriodlist);

		climSumList = new ArrayList<>();
		StringBuilder viewDetailLink = new StringBuilder();
		Date startdate;
		Date enddate;
		Date climateDate;

		List<ClimDetail> climSumListFilter = null;
		try {
			climSumListFilter = cvsReader.getCSVDataList();
		} catch (IOException e) {
			logger.error(e.getMessage());
		}

		if (!climatePeriodlist.equals("0")) {
			Date today = new Date();
			climateenddate = new SimpleDateFormat("dd/MM/yyyy").format(new Date());		
			Calendar calendar = Calendar.getInstance(); 
			 calendar.add(Calendar.YEAR, Integer.parseInt(climatePeriodlist));
			climatestartdate = new SimpleDateFormat("dd/MM/yyyy").format(calendar.getTime());	
		}		
		for (ClimDetail taskRow : climSumListFilter) {


			try {
				startdate = new SimpleDateFormat("dd/MM/yyyy").parse(climatestartdate);
				enddate = new SimpleDateFormat("dd/MM/yyyy").parse(climateenddate);
				climateDate = new SimpleDateFormat("dd/MM/yyyy").parse(taskRow.getDate());
				logger.info("Method: getSummaryList, Filtering startdate: " + startdate + ", enddate:" + enddate+ ", climateDate:" + climateDate+ ", Name:" + taskRow.getStation_Name());
				
				// Verify if within Date Range - if so...add it to the list
				//testDate.after(startDate) && testDate.before(endDate)
				if ((climateDate.after(startdate) && climateDate.before(enddate))) {
					ClimSum climSum = new ClimSum();
					climSum.setStation_Name(taskRow.getStation_Name());
					climSum.setDate(taskRow.getDate());
					climSum.setMean_Temp(taskRow.getMean_Temp());

					viewDetailLink = new StringBuilder();
					viewDetailLink.append("<a ").append("href=\"/climate/getStationDetail?Station_Name="
							+ taskRow.getStation_Name() + "\"><i>View Detail</i>" + "</a>");
					climSum.setAction(viewDetailLink.toString());

					climSumList.add(climSum);
				}

			} catch (ParseException e) {
				logger.error(e.getMessage());
			}
		}
		logger.info("Returing climSumList.size(): " + climSumList.size());
		return climSumList;
	}

	/*
	 * @parm
	 */
	public ClimDetail getStationDetailInfo(String Station_Name) {
		ClimDetail climDetail = new ClimDetail();

		logger.info("Method: getStationDetailInfo, Station_Name: " + Station_Name);

		try {
			climDetail = cvsReader.getCSVDataMap().get(Station_Name);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return climDetail;
	}
}

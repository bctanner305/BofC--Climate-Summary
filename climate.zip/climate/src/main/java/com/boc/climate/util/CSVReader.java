package com.boc.climate.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.boc.climate.bean.ClimDetail;

@Service
public class CSVReader {

	// Complete List of All Climate Results - Used by Climate Summary
	static List<ClimDetail> climDetailList = new ArrayList<>();
	
	// Complete HashMap of All Climate Results - Used by Climate Detail
	static HashMap<String, ClimDetail> climDetailMap     = new HashMap<>();

	@Value("${message.fileName}")
	static String fileName;
	
	// Logger
	private static final Logger logger = Logger.getLogger(CSVReader.class);

	/* Used to return the  Complete List of All Climate Results - Used by Climate Summary
	 */
	public List<ClimDetail> getCSVDataList() throws IOException {
		
		logger.info("method: getCSVDataList");

		if (climDetailList.isEmpty() ) {
			readBooksFromCSV();
		} 

		return climDetailList;
	}
	
	/* Used to return the  Complete List of All Climate Results - Used by Climate Summary
	 */
	public HashMap<String, ClimDetail> getCSVDataMap() throws IOException {
		
		logger.info("method: getCSVDataMap");

		if (climDetailMap.isEmpty()	) {
			readBooksFromCSV();
		} 

		return climDetailMap;
	}

	public static List<ClimDetail> readBooksFromCSV() throws IOException {

		logger.info("method: readBooksFromCSV");
		
		ConfigValues properties = new ConfigValues();
		properties.getPropValues();
		Path pathToFile = Paths.get(properties.getProp().getProperty("fileName"));

		logger.info("method: readBooksFromCSV, file to be loaded: " + properties.getProp().getProperty("fileName"));
		
		try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.UTF_8)) { // read the first
																								// line from the
			// Skip first line - 
			br.readLine();
			
			// text file
			String line = br.readLine();
			
			// Retrieve the CSV data and load it into detail list
			while (line != null) {
				String[] attributes = line.split(",", -1);
				ClimDetail climDetail = createClimDetail(attributes);
				// adding ClimDetail into ArrayList
				climDetailList.add(climDetail);
				
				// Add the ClimDetail to Hash Map
				climDetailMap.put(climDetail.getStation_Name(), climDetail);
				
				// read next line before looping
				// if end of file reached, line would be null
				line = br.readLine();
			}
		} catch (IOException ioe) {
			logger.error(ioe.getMessage());
		}
		
		logger.info("method: readBooksFromCSV, number CSV Records: " + climDetailList.size());

		return climDetailList;
	}

	private static ClimDetail createClimDetail(String[] metadata) {

		String Station_Name = metadata[0];
		String province = metadata[1];
		String Date = metadata[2];
		String Mean_Temp = metadata[3];
		String highest_Monthly_Maxi_Temp = metadata[4];
		String lowest_Monthly_Min_Temp = metadata[5];

		return new ClimDetail(Station_Name, Date, Mean_Temp, province, highest_Monthly_Maxi_Temp,
				lowest_Monthly_Min_Temp);
	}


}

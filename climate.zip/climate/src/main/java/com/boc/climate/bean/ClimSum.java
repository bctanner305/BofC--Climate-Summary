package com.boc.climate.bean;

import java.io.Serializable;
 
public class ClimSum implements Serializable {

	private static final long serialVersionUID = 1L;
	
	 protected String Station_Name;

	 protected String Date;

	 protected String Mean_Temp;
	 
	 private String action;

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getStation_Name() {
		return Station_Name;
	}

	public void setStation_Name(String station_Name) {
		Station_Name = station_Name;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}

	public String getMean_Temp() {
		return Mean_Temp;
	}

	public void setMean_Temp(String mean_Temp) {
		Mean_Temp = mean_Temp;
	}	
	
}

package com.boc.climate.startup;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletContextEvent;

import org.apache.log4j.Logger;

import com.boc.climate.bean.ClimDetail;
import com.boc.climate.util.CSVReader;

public class ClimateSessionListener implements javax.servlet.ServletContextListener {
	
	private static final Logger logger = Logger.getLogger(ClimateSessionListener.class);
  
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		
		CSVReader csvReader = new CSVReader();
		try {
			List<ClimDetail> climDetailList = csvReader.readBooksFromCSV();
			logger.info("method: contextInitialized, Start up - number CSV Records: " + climDetailList.size());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		// TODO Auto-generated method stub
		
	}

}

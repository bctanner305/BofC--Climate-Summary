package com.boc.climate.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.boc.climate.bean.ClimDetail;
import com.boc.climate.bean.ClimSum;
import com.boc.climate.service.RetrieveInfo;
import com.boc.climate.validator.ClimateSummaryValidator;

@Controller
public class ClimateSummary {

	@Autowired
	private RetrieveInfo retrieveInfo;

	private static final Logger logger = Logger.getLogger(ClimateSummary.class);

	/*
	 * Retrieve the Climate Summary Information. 
	 * 
	 */
	@RequestMapping(value = "/getSummary", method = RequestMethod.GET)
	public void getSummary(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value = "climatePeriodlist", required = false) String climatePeriodlist,
			@RequestParam(value = "climatestartdate", required = false) String climatestartdate,
			@RequestParam(value = "climateenddate", required = false) String climateenddate) {

		logger.info("Method: getSummary, climatestartdate: " + climatestartdate + ", climateenddate:" + climateenddate
				+ ", climatePeriodlist:" + climatePeriodlist);

		// Validate the Climate input (Start Date and End Date....if they selected the
		// Custom Range)
		if (climatePeriodlist.equals("0")) {

			ClimateSummaryValidator validator = new ClimateSummaryValidator();
			ArrayList<String> Errors = validator.validate(climatestartdate, climateenddate);

			if (!Errors.isEmpty()) {
				logger.info("Found errors");
				try {
					response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
							"Error Please try again! " + Errors.get(0));
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
				return;
			}
		}

		/* Response will be a String of JSONObject type */
		JSONObject taskResults = new JSONObject();

		/* JSON Array to store each row of the data table */
		JSONArray taskList = new JSONArray();

		// Retrieve the Climate Data Information
		List<ClimSum> climSumList = retrieveInfo.getSummaryList(climatestartdate, climateenddate, climatePeriodlist);

		// Format the Data to be returned
		for (ClimSum taskRow : climSumList) {
			JSONArray taskColumn = new JSONArray();

			taskColumn.put(taskRow.getStation_Name());
			taskColumn.put(taskRow.getDate());
			taskColumn.put(taskRow.getMean_Temp());
			taskColumn.put(taskRow.getAction());
			taskList.put(taskColumn);
		}

		// Return the Results
		try {

			taskResults.put("data", taskList);
		} catch (Exception e) {

			logger.error(e.getMessage());
			throw e;
		}
   
		response.setContentType("application/json;charset=ISO-8859-15");
		response.setHeader("Cache-Control", "no-store");
		PrintWriter out;

		try {
			out = response.getWriter();

			if (taskResults.toString() != null) {
				out.print(taskResults.toString());
			}

		} catch (Exception se) {
			logger.error(se.getMessage());

		}

	}

	/*
	 * Retrieve the Climate Detail Information.
	 * 
	 * Input is the Station Name 
	 * 
	 */
	@RequestMapping(value = "/getStationDetail", method = RequestMethod.GET)
	public ModelAndView getStationDetail(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value = "Station_Name", required = false) String Station_Name) {

		logger.info("Method: getStationDetail, Station_Name: " + Station_Name);

		ModelAndView mav = new ModelAndView();

		ClimDetail climDetail = retrieveInfo.getStationDetailInfo(Station_Name);
		mav.addObject("Station_Name", climDetail.getStation_Name());
		mav.addObject("Date", climDetail.getDate());
		mav.addObject("province", climDetail.getProvince());
		mav.addObject("Mean_Temp", climDetail.getMean_Temp());
		mav.addObject("highest_Monthly_Maxi_Temp", climDetail.getHighest_Monthly_Maxi_Temp());
		mav.addObject("lowest_Monthly_Min_Temp", climDetail.getLowest_Monthly_Min_Temp());

		mav.setViewName("jsp/ClimateDetail");

		return mav;

	}

}

package com.boc.climate.validator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.validation.Errors;

public class ClimateSummaryValidator {

	// Log4J logger.
	private final Logger logger = Logger.getLogger(ClimateSummaryValidator.class);

	/*
	 * Validate - ensure that the StartDate and End Date, are valid.
	 */
	public ArrayList<String> validate(String climatestartdate, String climateenddate) {

		logger.info(
	 			"Method: validate, climatestartdate: " + climatestartdate + ", climateenddate:" + climateenddate);

		ArrayList<String> strErrors = new ArrayList<String>(10);
		Date startdate = null;
		Date enddate = null;

		// Make sure a Date has been entered
		if (climatestartdate == null || climatestartdate.isEmpty()) {
			strErrors.add("Missing Start Date!!!");
		}

		if (climateenddate == null || climateenddate.isEmpty()) {
			strErrors.add("Missing End Date!!!");
		}

		if (strErrors.size() > 0) {
			return strErrors;
		}
		
		// Make sure the dates are in the format dd/MM/yyyy
		try {
			startdate = new SimpleDateFormat("dd/MM/yyyy").parse(climatestartdate);
		} catch (ParseException e) {
			strErrors.add("Invalid Start Date, should be in format dd/MM/yyyy!!!");
		}

		try {
			enddate = new SimpleDateFormat("dd/MM/yyyy").parse(climateenddate);
		} catch (ParseException e) {
			strErrors.add("Invalid End Date, should be in format dd/MM/yyyy!!!");
		}

		if (strErrors.size() > 0) {
			return strErrors;
		}
		
		// Verify Start Date is BEFORE end date
		if (!startdate.before(enddate)){
			strErrors.add("Start Date must be BEFORE the End Date!");
		}
		 
		// Return the Results
		return strErrors;

	}
}

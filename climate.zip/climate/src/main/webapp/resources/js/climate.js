function onDateSelectChange(mySelection) {

	var val = mySelection.options[mySelection.selectedIndex].value;
	
	if ($('#climatePeriodlist' ).val() == 0) 
		{ $('#climatePeriodlistCheck' ).prop('hidden', false);
	 } else { 
	 $('#climatePeriodlistCheck').prop('hidden', true);
	 }  
            
    if(val == '0' || val == null){
        var dateNewFormat, onlyDate, today = new Date();
     
        onlyDate = today.getDate();

        if (onlyDate.toString().length == 2) {
            dateNewFormat =  onlyDate + '/';
        }
        else {
            dateNewFormat = '-0' + onlyDate + '/';
        }
        
         dateNewFormat += (today.getMonth() + 1)  + '/'  +  today.getFullYear();
        
        $('#climateenddate').val(dateNewFormat);      
    }
}

function getContextPath() {
	return window.location.pathname.substring(0, window.location.pathname.indexOf("/", 2));
}

function performSearch() {

	$('#climateSummaryTable').dataTable({
		"bDestroy": true,
		"ajax": {    
			"url": getContextPath() + "/getSummary?climatePeriodlist="+$("#climatePeriodlist").val() + "&&climatestartdate=" + $("#climatestartdate").val() + "&&climateenddate="+ $("#climateenddate").val(),
			type: "GET",
			"error": function(xhr, textStatus, errorThrown) {
				$("#climateSummaryList").css({ 'display': "none" });
				alert("Start and End date are not properly formated.\n\nThe format of the dates is DD/MM/YYYY.\n and the Start Date must be before the End Date.");
			}
		},
		"searching": true,
		"ordering": true,
		"bInfo": true,
		"dom": "<\"top\"ilf>rt<\"bottom\"p><\"clear\">",
		"columnDefs": [{ "orderable": false, "targets": -1, class: "nowrap" }]
	});

 	$("#climateSummaryList").css({ 'display': "block" });

}
	
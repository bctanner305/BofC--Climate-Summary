package testRetrieveInfo;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.boc.climate.bean.ClimDetail;
import com.boc.climate.bean.ClimSum;
import com.boc.climate.service.RetrieveInfo;
import com.boc.climate.util.CSVReader;

class RetrieveInfoTests {

	@Autowired
	private RetrieveInfo retrieveInfo;

	/*
	 * Test Search Selection based on a Data Range
	 *   i.e., Last Year, Last 2 Years and Last 3 Years
	 */
	@Test
	void testDateRange() throws SecurityException, IllegalArgumentException, ReflectiveOperationException, IOException {

		// Create a test Data List
		List<ClimDetail> climDetailList = new ArrayList<>();

		ClimDetail climDetail = new ClimDetail();
		climDetail.setStation_Name("TESTNAME1");
		climDetail.setDate("01/01/2020");
		climDetailList.add(climDetail);
		climDetail = new ClimDetail();
		climDetail.setStation_Name("TESTNAME2");
		climDetail.setDate("01/01/2019");
		climDetailList.add(climDetail);

		// Update the Climate Detail List in the CSV reader
		Field cvsfield = CSVReader.class.getDeclaredField("climDetailList");
		cvsfield.setAccessible(true);
		cvsfield.set(null, climDetailList);

		// Update the CSVReader (which will have the new CSVData list) in the
		// RetrieveInfo
		RetrieveInfo retrieveInfo = new RetrieveInfo();
		CSVReader csvReader = new CSVReader();
		Field cvs1field = RetrieveInfo.class.getDeclaredField("cvsReader");
		cvs1field.setAccessible(true);
		cvs1field.set(retrieveInfo, csvReader);

		// Check Date Range for "Last Year"
		List<ClimSum> climSumList = retrieveInfo.getSummaryList("", "", "-1");
		assertEquals(1, climSumList.size());
		assertEquals("TESTNAME1", climSumList.get(0).getStation_Name());

		// Check Date Range for "Last 2 Years"
		climSumList = retrieveInfo.getSummaryList("", "", "-2");
		assertEquals(2, climSumList.size());

		// Check Date Range for "Last 3 Years"
		climSumList = retrieveInfo.getSummaryList("", "", "-3");
		assertEquals(2, climSumList.size());

	}
	
	/*
	 * Test Search Selection based on a Data Range (i.e, Custom Range)
	 * Simulating the condition where there is a Start Date and End Date
	 * entered by the User/  
	 */
	@Test
	void testcustomRange()
			throws SecurityException, IllegalArgumentException, ReflectiveOperationException, IOException {

		// Create a test Data List
		List<ClimDetail> climDetailList = new ArrayList<>();
		ClimDetail climDetail = new ClimDetail();
		climDetail.setStation_Name("TESTNAME1");
		climDetail.setDate("02/01/2020");
		climDetailList.add(climDetail);

		climDetail = new ClimDetail();
		climDetail.setStation_Name("TESTNAME2");
		climDetail.setDate("02/01/2019");
		climDetailList.add(climDetail);

		// Update the Climate Detail List in the CSV reader
		Field cvsfield = CSVReader.class.getDeclaredField("climDetailList");
		cvsfield.setAccessible(true);
		cvsfield.set(null, climDetailList);

		// Update the CSVReader (which will have the new CSVData list) in the
		// RetrieveInfo
		RetrieveInfo retrieveInfo = new RetrieveInfo();
		CSVReader csvReader = new CSVReader();
		Field cvs1field = RetrieveInfo.class.getDeclaredField("cvsReader");
		cvs1field.setAccessible(true);
		cvs1field.set(retrieveInfo, csvReader);

		List<ClimSum> climSumList = retrieveInfo.getSummaryList("01/01/2019", "01/01/2020", "0");
		assertEquals(1, climSumList.size());
		assertEquals("TESTNAME2", climSumList.get(0).getStation_Name());
		assertEquals("02/01/2019", climSumList.get(0).getDate());

		climSumList = retrieveInfo.getSummaryList("01/01/2018", "01/01/2020", "0");
		assertEquals(1, climSumList.size());

		climSumList = retrieveInfo.getSummaryList("01/01/2017", "01/01/2020", "0");
		assertEquals(1, climSumList.size());

	}

	/*
	 * Test to ensure all relevant Climate Detail Information is returned
	 */
	@Test
	void testCompleteClientDetailInformation()
			throws SecurityException, IllegalArgumentException, ReflectiveOperationException, IOException {

		// Create a test Data List
		List<ClimDetail> climDetailList = new ArrayList<>();

		ClimDetail climDetail = new ClimDetail();
		climDetail.setStation_Name("TESTNAME1");
		climDetail.setDate("02/01/2020");
		climDetail.setHighest_Monthly_Maxi_Temp("99");
		climDetail.setProvince("ONT");
		climDetail.setLowest_Monthly_Min_Temp("-0.1");
		climDetail.setMean_Temp("123");
		climDetailList.add(climDetail);

		// Update the Climate Detail List in the CSV reader
		Field cvsfield = CSVReader.class.getDeclaredField("climDetailList");
		cvsfield.setAccessible(true);
		cvsfield.set(null, climDetailList);

		// Update the CSVReader (which will have the new CSVData list) in the
		// RetrieveInfo
		RetrieveInfo retrieveInfo = new RetrieveInfo();
		CSVReader csvReader = new CSVReader();
		Field cvs1field = RetrieveInfo.class.getDeclaredField("cvsReader");
		cvs1field.setAccessible(true);
		cvs1field.set(retrieveInfo, csvReader);

		// Retrieve the Climate Data
		List<ClimSum> climSumList = retrieveInfo.getSummaryList("", "", "-3");
		assertEquals(1, climSumList.size());
		
		// Verify that all Climate Detail information is Correct
		assertEquals(climDetail.getStation_Name(), "TESTNAME1");
		assertEquals(climDetail.getDate(), "02/01/2020");
		assertEquals(climDetail.getHighest_Monthly_Maxi_Temp(), "99");
		assertEquals(climDetail.getProvince(), "ONT");
		assertEquals(climDetail.getLowest_Monthly_Min_Temp(), "-0.1");
		assertEquals(climDetail.getMean_Temp(), "123");
	}

	/*
	 * Test CLimate Detail Selection, to ensure a specific Climate
	 * Detail record can be retrieved.  This is based on Station
	 * Nane.
	 */
	@Test
	void testCLimateDetailRetrieveal()
			throws SecurityException, IllegalArgumentException, ReflectiveOperationException, IOException {

		// Create a test Data Hash MAP
		HashMap<String, ClimDetail> climDetailMap = new HashMap<>();
		ClimDetail climDetail = new ClimDetail();
		climDetail.setStation_Name("TESTNAME1");
		climDetail.setDate("02/01/2020");
		climDetailMap.put(climDetail.getStation_Name(), climDetail);

		climDetail = new ClimDetail();
		climDetail.setStation_Name("TESTNAME2");
		climDetail.setDate("02/01/2019");
		climDetailMap.put(climDetail.getStation_Name(), climDetail);

		// Update the Climate Detail MAP in the CSV Reader
		Field cvsfield = CSVReader.class.getDeclaredField("climDetailMap");
		cvsfield.setAccessible(true);
		cvsfield.set(null, climDetailMap);

		// Update the CSVReader (which will have the new CSVData list) in the
		// RetrieveInfo
		RetrieveInfo retrieveInfo = new RetrieveInfo();
		CSVReader csvReader = new CSVReader();
		Field cvs1field = RetrieveInfo.class.getDeclaredField("cvsReader");
		cvs1field.setAccessible(true);
		cvs1field.set(retrieveInfo, csvReader);

		// Retrieve a Specific Climate Detail (based on STATION_NAME)
		ClimDetail climDetailRetrieved = retrieveInfo.getStationDetailInfo("TESTNAME1");
		assertEquals("TESTNAME1", climDetailRetrieved.getStation_Name());
		assertEquals("02/01/2020", climDetailRetrieved.getDate());

	}

}

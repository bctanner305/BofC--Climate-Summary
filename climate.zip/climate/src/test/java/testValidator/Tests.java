package testValidator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import com.boc.climate.validator.ClimateSummaryValidator;

class Tests {

	/*
	 *  Tests where Start Date and End Date is NULL
	 */
	@Test
	public void TestStartAndEndNull() {
		
		ClimateSummaryValidator ClimateSummaryValidator = new ClimateSummaryValidator();
		
		ArrayList<String> test1Results =  ClimateSummaryValidator.validate(null, null);
		
		assertTrue(!test1Results.isEmpty());
		assertTrue(test1Results.size() == 2);
		assertEquals(test1Results.get(0), "Missing Start Date!!!");
		assertEquals(test1Results.get(1), "Missing End Date!!!");
		
	}

	/*
	 *  Tests where Start Date and End Date is EMPTY
	 */
	@Test
	public void testStartAndEndEmpty() {
		
		ClimateSummaryValidator ClimateSummaryValidator = new ClimateSummaryValidator();
		
		ArrayList<String> test1Results =  ClimateSummaryValidator.validate("", "");
		
		assertTrue(!test1Results.isEmpty());
		assertTrue(test1Results.size() == 2);
		assertEquals(test1Results.get(0), "Missing Start Date!!!");
		assertEquals(test1Results.get(1), "Missing End Date!!!");
		
	}

	/*
	 *  Tests where Start Date and End Date is Valid
	 */
	@Test
	public void testStartAndEndValid() {
		
		ClimateSummaryValidator ClimateSummaryValidator = new ClimateSummaryValidator();
		
		ArrayList<String> test1Results =  ClimateSummaryValidator.validate("01/01/2012", "01/01/2020");
		
		assertTrue(test1Results.isEmpty());
			
	}

	/*
	 *  Tests where Start Date and End Date are in an INVALID order
	 */
	@Test
	public void testStartAndEndInvalidOrder() {
		
		ClimateSummaryValidator ClimateSummaryValidator = new ClimateSummaryValidator();
		
		ArrayList<String> test1Results =  ClimateSummaryValidator.validate("01/01/2020", "01/01/2012");
		
		assertTrue(!test1Results.isEmpty());
		assertTrue(test1Results.size() == 1);
		assertEquals(test1Results.get(0), "Start Date must be BEFORE the End Date!");
	}

}
